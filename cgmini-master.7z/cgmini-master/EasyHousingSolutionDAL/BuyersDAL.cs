﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyHousingSolutionEntity;
using System.Data;
using System.Data.SqlClient;
using EHSException;

namespace EasyHousingSolutionDAL
{
    public class BuyersDAL
    {
        SqlConnection connection = new SqlConnection(GlobalData.ConnectionString);

        public int getStateId(string StateName)
        {
            try
            {
                int StateId = 0;
                SqlCommand command = new SqlCommand();
                command.CommandText = "Abhi.uspGetStateId";
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.Parameters.AddWithValue("@StateName", StateName);
                connection.Open();
                int retrieveStateId = int.Parse(command.ExecuteScalar().ToString());
                //object retrieveStateId = command.ExecuteScalar().ToString();
                StateId = int.Parse(retrieveStateId.ToString());
                connection.Close();
                return StateId;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public int getCityId(string CityName)
        {
            try
            {
                int CityId = 0;
                SqlCommand command = new SqlCommand();
                command.CommandText = "Abhi.uspGetCityId";
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection; ;

                command.Parameters.AddWithValue("@cityName", CityName);
                connection.Open();
                object retrieveCityId = command.ExecuteScalar().ToString();
                CityId = int.Parse(retrieveCityId.ToString());
                connection.Close();
                return CityId;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public bool AddBuyerDAL(Buyer newBuyer)
        {
            bool BuyerAdded = false;
            try
            {
                string Query = "Abhi.uspAddBuyer";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserName", newBuyer.UserName);
                command.Parameters.AddWithValue("@FirstName", newBuyer.FirstName);
                command.Parameters.AddWithValue("@LastName", newBuyer.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", newBuyer.DateOfBirth);
                command.Parameters.AddWithValue("@PhoneNumber", newBuyer.PhoneNo);
                command.Parameters.AddWithValue("@EmailId", newBuyer.EmailId);
                command.Parameters.AddWithValue("@Adress", newBuyer.Address);
                int stateId = getStateId(newBuyer.StateName);
                int cityId = getCityId(newBuyer.CityName);
                command.Parameters.AddWithValue("@StateId", stateId);
                command.Parameters.AddWithValue("@CityId", cityId);
                //command.Parameters.AddWithValue("@Password", newBuyer.Address);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
                BuyerAdded = true;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return BuyerAdded;
        }

        public List<Buyer> GetAllBuyersDAL()
        {
            try
            {
                List<Buyer> BuyerList = new List<Buyer>();
                string Query = "Abhi.uspDisplayBuyer";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader Reader = command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        Buyer s = new Buyer();
                        s.BuyerId = int.Parse(Reader[0].ToString());
                        s.FirstName = Reader[1].ToString();
                        s.LastName = Reader[2].ToString();
                        s.DateOfBirth = DateTime.Parse(Reader[3].ToString());
                        s.PhoneNo = long.Parse(Reader[4].ToString());
                        s.EmailId = Reader[5].ToString();
                        BuyerList.Add(s);
                    }
                }
                connection.Close();
                return BuyerList;
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public int getBuyerIdDAL(string BuyerName)
        {
            int BuyerId = 0;
            try
            {
                string Query = "Abhi.uspGetBuyerId";
                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserName", BuyerName);

                connection.Open();
                Object RetrievedBuyerId = command.ExecuteScalar().ToString();
                BuyerId = int.Parse(RetrievedBuyerId.ToString());
                connection.Close();
            }
            catch (Exception ex)
            {
                throw new EasyHousingSolutionException(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return BuyerId;
        }
    }
}
